import React, { useState, useEffect } from 'react';

const UserData = () => {
  // State to hold the user data, loading state, and error state
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // useEffect hook to fetch user data when the component mounts
  useEffect(() => {
    // Function to fetch user data from the API
    const fetchUserData = async () => {
      try {
        // Replace with your API URL
        const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
        
        // Check if the response is OK (status 200)
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const data = await response.json();
        setUserData(data); // Set the user data in state
      } catch (err) {
        setError(err.message); // Set the error message if an error occurs
      } finally {
        setLoading(false); // Set loading to false once data is fetched or error occurs
      }
    };

    fetchUserData(); // Call the function to fetch data
  }, []); // Empty dependency array ensures the effect runs only once when the component is mounted

  // Conditional rendering based on loading, error, or data availability
  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div style={{ textAlign: 'center', marginTop: '20px' }}>
      <h2>User Data</h2>
      <div>
        <h3>{userData.name}</h3>
        <p>Email: {userData.email}</p>
        <p>Phone: {userData.phone}</p>
        <p>Website: {userData.website}</p>
      </div>
    </div>
  );
};

export default UserData;
