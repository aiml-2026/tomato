import React from 'react';
import UserData from './UserData'; // Import the UserData component

function App() {
  return (
    <div className="App">
      <UserData />
    </div>
  );
}

export default App;
