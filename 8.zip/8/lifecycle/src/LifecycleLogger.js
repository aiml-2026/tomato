import React, { Component } from 'react';

class LifecycleLogger extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0, // We will use this to trigger updates
    };
    console.log('[Constructor] Component is initializing');
  }

  // 1. Mounting Phase: Called after the component has mounted
  componentDidMount() {
    console.log('[ComponentDidMount] Component has mounted');
  }

  // 2. Updating Phase: Decides whether a component should update
  shouldComponentUpdate(nextProps, nextState) {
    console.log('[ShouldComponentUpdate] Checking if component should update');
    console.log('Current state:', this.state);
    console.log('Next state:', nextState);
    return true; // Allow the update
  }

  // 3. Updating Phase: After the component has updated
  componentDidUpdate(prevProps, prevState) {
    console.log('[ComponentDidUpdate] Component has updated');
    console.log('Previous state:', prevState);
    console.log('Current state:', this.state);
  }

  // 4. Unmounting Phase: Before the component is removed from the DOM
  componentWillUnmount() {
    console.log('[ComponentWillUnmount] Component is about to unmount');
  }

  // Method to increment counter to trigger state updates
  incrementCounter = () => {
    this.setState({ counter: this.state.counter + 1 });
  };

  render() {
    console.log('[Render] Rendering the component');
    return (
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h1>React Lifecycle Debugger</h1>
        <p>Counter: {this.state.counter}</p>
        <button onClick={this.incrementCounter}>Increment Counter</button>
      </div>
    );
  }
}

export default LifecycleLogger;
