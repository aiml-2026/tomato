import React from 'react';
import LifecycleLogger from './LifecycleLogger'; // Import the LifecycleLogger component

function App() {
  return (
    <div className="App">
      <LifecycleLogger />
    </div>
  );
}

export default App;
