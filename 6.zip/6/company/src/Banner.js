import React from 'react';
import './Banner.css'; // Import a CSS file for styling (optional)

// Banner component
const Banner = ({ message }) => {
    return (
        <div className="banner">
            <h1>{message}</h1>
        </div>
    );
};

export default Banner;
