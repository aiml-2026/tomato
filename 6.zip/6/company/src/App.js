import React from 'react';
import Banner from './Banner'; // Import the Banner component

function App() {
    return (
        <div className="App">
            <Banner message="Hello, React!" />

        </div>
    );
}

export default App;
