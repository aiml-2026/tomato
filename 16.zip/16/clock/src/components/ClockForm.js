// src/components/ClockForm.js
import React, { useState } from 'react';
import { createClock } from './api';

const ClockForm = () => {
  const [name, setName] = useState('');
  const [timeZone, setTimeZone] = useState('UTC');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name || !timeZone) {
      setError('Please fill in all fields');
      return;
    }

    const clockData = { name, timeZone };

    createClock(clockData)
      .then(() => {
        setName('');
        setTimeZone('UTC');
        setError('');
      })
      .catch((error) => {
        console.error('Error creating clock:', error);
      });
  };

  return (
    <div>
      <h2>Create Clock</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Clock Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <select
          value={timeZone}
          onChange={(e) => setTimeZone(e.target.value)}
        >
          <option value="UTC">UTC</option>
          <option value="PST">PST</option>
          <option value="EST">EST</option>
          <option value="CET">CET</option>
        </select>
        <button type="submit">Create Clock</button>
      </form>
    </div>
  );
};

export default ClockForm;
