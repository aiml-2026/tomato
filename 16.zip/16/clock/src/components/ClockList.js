// src/components/ClockList.js
import React, { useEffect, useState } from 'react';
import { getAllClocks, deleteClock } from './api';

const ClockList = () => {
  const [clocks, setClocks] = useState([]);

  useEffect(() => {
    // Fetch clocks from backend on component mount
    getAllClocks()
      .then((response) => {
        setClocks(response.data);
      })
      .catch((error) => {
        console.error('Error fetching clocks:', error);
      });
  }, []);

  const handleDelete = (id) => {
    deleteClock(id)
      .then(() => {
        setClocks(clocks.filter(clock => clock._id !== id));
      })
      .catch((error) => {
        console.error('Error deleting clock:', error);
      });
  };

  return (
    <div>
      <h2>Clock List</h2>
      <ul>
        {clocks.map((clock) => (
          <li key={clock._id}>
            <p>{clock.name} ({clock.timeZone})</p>
            <p>Current Time: {new Date(clock.currentTime).toLocaleString()}</p>
            <button onClick={() => handleDelete(clock._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ClockList;
