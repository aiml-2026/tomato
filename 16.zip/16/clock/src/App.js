// src/App.js
import React from 'react';
import ClockForm from './components/ClockForm';
import ClockList from './components/ClockList';

const App = () => {
  return (
    <div>
      <h1>Clock Management System</h1>
      <ClockForm />
      <ClockList />
    </div>
  );
};

export default App;
