// src/api.js
import axios from 'axios';

const API_URL = 'http://localhost:5000/api/clocks';  // Backend API URL

// Create new clock
export const createClock = (clockData) => {
  return axios.post(API_URL, clockData);
};

// Get all clocks
export const getAllClocks = () => {
  return axios.get(API_URL);
};

// Get a clock by ID
export const getClockById = (id) => {
  return axios.get(`${API_URL}/${id}`);
};

// Update a clock
export const updateClock = (id, clockData) => {
  return axios.put(`${API_URL}/${id}`, clockData);
};

// Delete a clock
export const deleteClock = (id) => {
  return axios.delete(`${API_URL}/${id}`);
};
