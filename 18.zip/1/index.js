console.log('Hello! Welcome to my website.');
const _ = require('lodash');
console.log('Unique values:', _.uniq([1, 2, 2, 3, 4, 4]));