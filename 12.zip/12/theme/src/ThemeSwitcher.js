import React from 'react';
import { useTheme } from './ThemeContext'; // Use the custom hook to access theme context

const ThemeSwitcher = () => {
  const { theme, toggleTheme } = useTheme(); // Get theme and toggle function

  return (
    <div>
      <button onClick={toggleTheme} style={{ padding: '10px', fontSize: '16px' }}>
        Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
      </button>
    </div>
  );
};

export default ThemeSwitcher;
