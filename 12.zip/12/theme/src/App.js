import React from 'react';
import { ThemeProvider } from './ThemeContext'; // Import ThemeProvider
import ThemeSwitcher from './ThemeSwitcher'; // Import the theme switcher component
import './App.css';

function App() {
  return (
    <ThemeProvider>
      <div className="App">
        <h1>React Theme Switcher</h1>
        <ThemeSwitcher />
        <div className="content">
          <p>Here is some content in your theme mode.</p>
        </div>
      </div>
    </ThemeProvider>
  );
}

export default App;
