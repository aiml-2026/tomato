// controllers/clockController.js
const Clock = require('../models/clockModel');

// Create a new clock
const createClock = async (req, res) => {
  try {
    const clock = new Clock(req.body);
    await clock.save();
    res.status(201).json(clock); // Return created clock
  } catch (error) {
    res.status(400).json({ message: 'Error creating clock', error });
  }
};

// Get all clocks
const getAllClocks = async (req, res) => {
  try {
    const clocks = await Clock.find();
    res.status(200).json(clocks);
  } catch (error) {
    res.status(400).json({ message: 'Error fetching clocks', error });
  }
};

// Get clock by ID
const getClockById = async (req, res) => {
  try {
    const clock = await Clock.findById(req.params.id);
    if (!clock) {
      return res.status(404).json({ message: 'Clock not found' });
    }
    res.status(200).json(clock);
  } catch (error) {
    res.status(400).json({ message: 'Error fetching clock', error });
  }
};

// Update clock by ID
const updateClock = async (req, res) => {
  try {
    const clock = await Clock.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!clock) {
      return res.status(404).json({ message: 'Clock not found' });
    }
    res.status(200).json(clock);
  } catch (error) {
    res.status(400).json({ message: 'Error updating clock', error });
  }
};

// Delete clock by ID
const deleteClock = async (req, res) => {
  try {
    const clock = await Clock.findByIdAndDelete(req.params.id);
    if (!clock) {
      return res.status(404).json({ message: 'Clock not found' });
    }
    res.status(200).json({ message: 'Clock deleted successfully' });
  } catch (error) {
    res.status(400).json({ message: 'Error deleting clock', error });
  }
};

module.exports = {
  createClock,
  getAllClocks,
  getClockById,
  updateClock,
  deleteClock,
};
