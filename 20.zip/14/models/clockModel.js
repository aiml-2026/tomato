// models/clockModel.js
const mongoose = require('mongoose');

const clockSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  timeZone: {
    type: String,
    required: true,
  },
  currentTime: {
    type: Date,
    default: Date.now,
  },
});

const Clock = mongoose.model('Clock', clockSchema);

module.exports = Clock;
