// routes/clockRoutes.js
const express = require('express');
const {
  createClock,
  getAllClocks,
  getClockById,
  updateClock,
  deleteClock,
} = require('../controllers/clockController');

const router = express.Router();

// POST /clocks - Create a new clock
router.post('/clocks', createClock);

// GET /clocks - Get all clocks
router.get('/clocks', getAllClocks);

// GET /clocks/:id - Get clock by ID
router.get('/clocks/:id', getClockById);

// PUT /clocks/:id - Update clock by ID
router.put('/clocks/:id', updateClock);

// DELETE /clocks/:id - Delete clock by ID
router.delete('/clocks/:id', deleteClock);

module.exports = router;
