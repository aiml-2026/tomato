import React, { useState } from 'react';

const Counter = () => {
  // State to store the current counter value
  const [count, setCount] = useState(0);

  // Function to increment the counter
  const increment = () => {
    setCount(count + 1);
  };

  // Function to decrement the counter
  const decrement = () => {
    setCount(count - 1);
  };

  // Function to reset the counter to 0
  const reset = () => {
    setCount(0);
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Task Tracker Counter</h1>
      <p style={{ fontSize: '2rem' }}>Count: {count}</p>

      {/* Buttons for increment, decrement, and reset */}
      <div>
        <button onClick={increment} style={{ padding: '10px 20px', margin: '10px' }}>
          Increment
        </button>
        <button onClick={decrement} style={{ padding: '10px 20px', margin: '10px' }}>
          Decrement
        </button>
        <button onClick={reset} style={{ padding: '10px 20px', margin: '10px' }}>
          Reset
        </button>
      </div>
    </div>
  );
};

export default Counter;
