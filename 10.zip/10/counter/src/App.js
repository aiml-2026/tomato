import React from 'react';
import Counter from './Counter'; // Import the Counter component

function App() {
  return (
    <div className="App">
      <Counter />
    </div>
  );
}

export default App;
