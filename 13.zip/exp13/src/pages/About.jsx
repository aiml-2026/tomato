import React from 'react';

const About = () => (
  <div>
    <h1>About Page</h1>
    <p>This is the About page where we share information about our application.</p>
  </div>
);

export default About;
