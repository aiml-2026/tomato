import React from 'react';

const Contact = () => (
  <div>
    <h1>Contact Page</h1>
    <p>Reach out to us on the Contact page!</p>
  </div>
);

export default Contact;
