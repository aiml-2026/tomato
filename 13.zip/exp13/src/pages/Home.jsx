import React from 'react';

const Home = () => (
  <div>
    <h1>Home Page</h1>
    <p>Welcome to the Home page!</p>
  </div>
);

export default Home;
