const http = require('http');

const server = http.createServer((req, res) => {
    // Set common response headers
    res.writeHead(200, { 'Content-Type': 'text/plain' });

    // Handle GET and POST requests
    if (req.method === 'GET') {
        res.end('GET request received');
    } else if (req.method === 'POST') {
        res.end('POST request received');
    } else {
        res.end('Unsupported request method');
    }
});

const PORT = 4000;
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
