import React from 'react';
import UserProfile from './Profile';

function App() {
    return (
        <div className="App">
            <UserProfile
                name="John Doe"
                age={28}
                email="john.doe@example.com"
                bio="A software developer with a passion for creating user-friendly applications."
                location="San Francisco, CA"
            />
        </div>
    );
}

export default App;
