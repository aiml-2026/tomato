import React, { useState } from 'react';
import './Profile.css'; // Optional CSS file for styling

const UserProfile = ({ name, age, email, bio, location }) => {
    const [showDetails, setShowDetails] = useState(false); // State for toggling details

    const toggleDetails = () => {
        setShowDetails(!showDetails); // Toggle the state
    };

    return (
        <div className="user-profile-card">
            <h2>{name}</h2>
            <p>Age: {age}</p>
            <p>Email: {email}</p>

            {/* Button to toggle additional details */}
            <button onClick={toggleDetails}>
                {showDetails ? 'Hide Details' : 'Show Details'}
            </button>

            {/* Conditional rendering for additional details */}
            {showDetails && (
                <div className="additional-info">
                    <p><strong>Bio:</strong> {bio}</p>
                    <p><strong>Location:</strong> {location}</p>
                </div>
            )}
        </div>
    );
};

export default UserProfile;
