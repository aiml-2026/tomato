const fs = require('fs').promises; // Use Promises API

// Read the file using async/await
async function readConfig() {
    try {
        const data = await fs.readFile('config.json', 'utf8');
        const config = JSON.parse(data);
        console.log('Configuration (Async/Await):', config);
    } catch (err) {
        console.error('Error:', err);
    }
}

readConfig();
