const fs = require('fs').promises; // Use Promises API

// Read the file using promises
fs.readFile('config.json', 'utf8')
    .then(data => {
        const config = JSON.parse(data);
        console.log('Configuration (Promise):', config);
    })
    .catch(err => {
        console.error('Error:', err);
    });
