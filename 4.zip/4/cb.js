const fs = require('fs'); // File system module

// Read the file using a callback
fs.readFile('config.json', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading file:', err);
        return;
    }
    try {
        const config = JSON.parse(data);
        console.log('Configuration (Callback):', config);
    } catch (parseError) {
        console.error('Error parsing JSON:', parseError);
    }
});
