import React from 'react';
import WarningMessage from './WarningMessage'; // Import the WarningMessage component

function App() {
  return (
    <div className="App">
      <WarningMessage />
    </div>
  );
}

export default App;
