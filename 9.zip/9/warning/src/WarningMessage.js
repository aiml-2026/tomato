import React, { useState } from 'react';

const WarningMessage = () => {
  // State to toggle the visibility of the warning message
  const [showWarning, setShowWarning] = useState(false);

  // Function to toggle the showWarning state
  const toggleWarning = () => {
    setShowWarning(!showWarning);
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Warning Message Toggle</h1>
      
      {/* Button to toggle the warning message visibility */}
      <button onClick={toggleWarning} style={{ padding: '10px 20px', margin: '20px' }}>
        {showWarning ? 'Hide Warning' : 'Show Warning'}
      </button>

      {/* Conditional rendering of the warning message */}
      {showWarning && (
        <div style={{
          backgroundColor: 'yellow',
          color: 'black',
          padding: '15px',
          border: '1px solid orange',
          borderRadius: '5px',
          marginTop: '20px'
        }}>
          <strong>Warning!</strong> This is a critical message.
        </div>
      )}
    </div>
  );
};

export default WarningMessage;
